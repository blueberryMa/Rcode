rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data.xlsx")
#检测正态分布
shapiro.test(patients$HGBPRE)
shapiro.test(patients$HGBPOST)
#符合正态分布，配对t检验(两个样本的数量必须相等且一一对应)
#不要采用HGB ~ GROUP此种方式，因为没对应
t.test(patients$HGBPRE,patients$HGBPOST, paired = TRUE)
patients2 <- read_excel("C:/Users/wizar/Desktop/rdata/data2.xlsx")
shapiro.test(patients2$HGBPRE)
shapiro.test(patients2$HGBPOST)
#不符合正态分布的配对Wilcoxon符号秩检验
wilcox.test(patients$HGBPRE,patients$HGBPOST, paired=TRUE)
R1 <- data.frame(matrix(sample(1:100, 10*20, replace = TRUE), nrow = 10, ncol = 20))
R2 <- data.frame(matrix(sample(1:100, 10*20, replace = TRUE), nrow = 10, ncol = 20))
library(writexl)
write_xlsx(R1,'dataa.xlsx')
write_xlsx(R1,'datab.xlsx')
