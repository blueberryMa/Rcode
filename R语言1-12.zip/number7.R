rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data7.xlsx")

patients$TIME=as.factor(patients$TIME)
patients$ID=as.factor(patients$ID)
#符合正态分布，One-way Repeated Measures Anova
#Anovaresult<- aov(H~TIME + Error(ID/TIME),data = patients)需要球形检验
#summary(Anovaresult)
library(rstatix)
Anovare <- anova_test(data = patients, dv =H, wid = ID, within = TIME)
Anovare
#不符合正态分布，friedman检验
friedman.test(y = patients$H, groups = patients$TIME, blocks =patients$ID)

