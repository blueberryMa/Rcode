rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data10.1.xlsx")
#检验正态性
shapiro.test(patients$HEIGHT)
shapiro.test(patients$WEIGHT)
#符合正态分布 用pearson相关分析
cor.test(patients$HEIGHT, patients$WEIGHT,method = "pearson", conf.level = 0.95)
#不符合正态分布 用sperman相关分析
patients2 <- read_excel("C:/Users/wizar/Desktop/rdata/data10.2.xlsx")
shapiro.test(patients2$HEIGHT)
shapiro.test(patients2$WEIGHT)
cor.test(patients2$HEIGHT, patients2$WEIGHT,method = "spearman", conf.level = 0.95)
