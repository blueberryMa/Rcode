#cox回归
rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data12.xlsx")
str(patients) 
patients$Gender=factor(patients$Gender)
patients$PS=factor(patients$PS,levels=c(0,1,2),labels=c('评分0','评分1','评分2'))
str(patients) 
library(survival) 
#直接多变量分析代入cox回归
modelcox=coxph(Surv(Month,OS)~PS+Age+Gender,data=patients) 
summary(modelcox) 
#测评分的p值
library(aod)
wald.test(b = coef(modelcox), Sigma = vcov(modelcox),Terms = 1:2)

