rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data.xlsx")
View(patients)
a=patients[1:15,4]
b=patients[16:30,4]
shapiro.test(a$HGB)
shapiro.test(b$HGB)
#两组皆为正态分布
#p value 大于0.05
#测试方差齐性 levenetest
library(lawstat)
levene.test(patients$HGB,patients$GROUP,location='mean')
#结果p大于0.05 方差齐
#Student t test
t.test(HGB~GROUP,data=patients,var.equal=TRUE)
#welch t test
t.test(HGB~GROUP,data=patients,var.equal=FALSE)
#不齐 用曼惠特尼u检验(也称威尔科克森秩和检验（Wilcoxon rank-sum test ）)
wilcox.test(HGB~GROUP,data=patients)