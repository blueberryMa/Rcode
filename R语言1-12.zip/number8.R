rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data8.xlsx")
#制作4格表
data=matrix(c(48,30,15,14),nr=2,dimnames = list(c("A group","B group"),c("YES","No")))  
data
chisquare=chisq.test(data,correct = FALSE)
chisquare
chisquare$expected
#假设期望频数小于5大于等于1，就用校正卡方检验
chisquare2=chisq.test(data,correct = TRUE)
chisquare2
#样本小于40或期望频数小于1.可以用fisher精确概率法
data2=matrix(c(48,0,15,14),nr=2,dimnames = list(c("A group","B group"),c("YES","No"))) 
chisquare3=chisq.test(data2,correct = FALSE)
chisquare3$expected
fisher.test(data2)
#计算百分比
result=prop.table(data,margin = 1)
result
