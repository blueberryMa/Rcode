rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data6.xlsx")
a=patients$HGB[1:15]
b=patients$HGB[16:30]
c=patients$HGB[31:45]
patients$GROUP=as.factor(patients$GROUP)
#验证正态分布
shapiro.test(a)
shapiro.test(b)
shapiro.test(c)

library(lawstat)
levene.test(patients$HGB,patients$GROUP,location='mean')
#验证方差齐性
bartlett.test(HGB ~ GROUP, data = patients)
#普通anova
Anovaresult<- aov(HGB ~ GROUP, data = patients)
summary(Anovaresult)
#方差不齐，welch anova(假设)
?oneway.test
oneway.test(HGB ~ GROUP, data = patients, var.equal = FALSE)
#不符合正态分布 用Kruskal-Wallis rank sum test(假设)
kruskal.test(HGB ~ GROUP, data =  patients)
#两两比较 turkey test
TukeyHSD(Anovaresult)
