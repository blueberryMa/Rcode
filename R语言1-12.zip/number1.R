rm(list = ls())
# 读取excel
library(readxl)
patients =read_excel("C:/Users/wizar/Desktop/rr/adc.xlsx")
View(patients)
# 读csv
library(haven)
patients=read_csv("C:/Users/wizar/Desktop/rr/adc.sav")
# 写excel
library(writexl)
write_xlsx(patients,'patients.xlsx')
# 写csv
write.csv(patients,'patients.csv')
#写sav
write_sav(patients,'patients.sav')