#mcnemar test
rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data9.1.xlsx")
data <- matrix(c(48,30,15,14), nrow = 2,
               dimnames = list("A" = c("positive", "negative"),
                               "B" = c("positive", "negative")))
data
mcnemar.test(data, correct=FALSE) 
#R*C表结局变量有序
rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data9.2.xlsx")
patients$EFFECT=as.factor(patients$EFFECT)
patients$GROUP=as.factor(patients$GROUP)
kruskal.test(EFFECT ~ GROUP, data =  patients)
#R×C 双向有序属性相同
rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data9.3.xlsx")
data <- matrix(c(7,34,23,12,41,44,14,12,45), nrow = 3,
               dimnames = list("doctor1" = c("0", "1","2"),
                               "doctor2" = c("0", "1","2")))
mcnemar.test(data, correct=FALSE) 


