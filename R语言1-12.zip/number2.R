getwd()
setwd()
rm(list=ls())
#数据类型
a=1
b<- 2
c='b'
d="c"
e=TRUE
f1='True'
f2=T
#f3=True
factor1=as.factor('tumor')
vec1= c(1,2,3,4)
vec2=c(1,T,F,"b")
vec3=c(1,T,F)
arr1=array(1:10)
list1=list(vec1,vec2,vec3)
Dataframe=data.frame(a=c(1,2,3,4),b=c(5,6,7,8))
col=c('h','i')
row=c('j','k')
list2=list(row,col)
Matrix=matrix(vec1,2,2,byrow=TRUE,dimnames=list2)
#matrix(data,nrow,ncol,byrow,dimnames)
#函数
hanshu=function(x, y) {
  result <- x ^ y
  return(result)
}

a <- 2
b <- 3
d <- hanshu(a, b)
d
# 常用函数
y1=sort(vec1)
y2=max(vec1)
y3=min(vec1)
y1
y2
y3
#包的详细介绍
help(package="haven")
rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rr/ADC.xlsx",col_names = FALSE)
#excel中提取数据
result1=patients[,1]
result2=patients[1,]
result3=patients[,1:10]
result4=patients[1:10,]
result5=patients[2,3]
s=c(3,5,6,7)
result6=patients[2,s]
