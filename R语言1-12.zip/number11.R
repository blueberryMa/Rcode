#二元logistic回归
rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data11.xlsx")
patients$Gender=factor(patients$Gender)
patients$PS=factor(patients$PS,levels=c(0,1,2),ordered='T',labels=c('评分0','评分1','评分2'))
patients$Complication=factor(patients$Complication)
modell=glm(Complication~PS+Gender+Age,data=patients,family='binomial')
summary(modell)
library(aod)
wald.test(b = coef(modell), Sigma = vcov(modell),Terms = 2:3)
#OR值
exp(coef(modell))
# 95%可信区间
exp(confint.default(modell))

