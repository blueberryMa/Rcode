rm(list=ls())
library(readxl)
patients <- read_excel("C:/Users/wizar/Desktop/rdata/data.xlsx")
View(patients)
shapiro.test(patients$HGB)
#p value 大于0.05 用单样本t检验
# 进行t检验
?t.test
t.test(patients$HGB,mu=145,conf.level=0.95)
library(readxl)
patients2 <- read_excel("C:/Users/wizar/Desktop/rdata/data2.xlsx")
shapiro.test(patients2$HGB)
#p value 小于0.05 Wilcoxon符号秩检验
?wilcox.test
wilcox.test(patients2$HGB,mu=145,conf.level=0.95)
